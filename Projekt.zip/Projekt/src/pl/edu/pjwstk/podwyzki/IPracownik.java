package pl.edu.pjwstk.podwyzki;

public interface IPracownik {

   public double obliczPensje();

}
