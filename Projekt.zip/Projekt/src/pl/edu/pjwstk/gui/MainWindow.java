package pl.edu.pjwstk.gui;

import pl.edu.pjwstk.model.*;
import pl.edu.pjwstk.util.Datasource;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.geom.Arc2D;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

public class MainWindow {
    final String PRAC_ADMINISTRACYJNY = "ADMINISTRACYJNY";
    final String PRAC_FIZYCZNY = "FIZYCZNY";
    final String PRAC_KIEROWNIK = "KIEROWNIK";

    public MainWindow() {
        godzinyLiczba.setVisible(false);
        fizycznyGodzinyLabel.setVisible(false);
        bonusField.setVisible(false);
        bonusLabel.setVisible(false);

        //[BEGIN] Ustawienie przykladowych danych w polach
        setSampleData();

        wczytajListe.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                int returnVal = fc.showOpenDialog(null);
                if (returnVal == JFileChooser.APPROVE_OPTION) {
                    File file = fc.getSelectedFile();
                    try {
                        MainWindow.this.pracownikList = Datasource.deserialize(fc.getSelectedFile().getAbsolutePath());
                    } catch (IOException e) {
                        JOptionPane.showMessageDialog(null, "Nie mozna odczytac pliku " + fc.getSelectedFile().getName(),
                                "InfoBox: ", JOptionPane.ERROR_MESSAGE);
                    }
                }
                MainWindow.this.refreshData(MainWindow.this.tabelaPracownikow, MainWindow.this.pracownikList);
            }
        });


        tabelaPracownikow.setAutoCreateRowSorter(true);
        tabelaPracownikow.setFillsViewportHeight(true);
        tabelaPracownikow.setPreferredScrollableViewportSize(new Dimension(350, 200));
        tabelaPracownikow.setModel(getPracownikTableModel());

        usunPracownikaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {

                int selectedRow = MainWindow.this.tabelaPracownikow.getSelectedRow();
                if (selectedRow >= 0) {
                    MainWindow.this.pracownikList.remove(selectedRow);
                    MainWindow.this.refreshData(MainWindow.this.tabelaPracownikow, MainWindow.this.pracownikList);
                } else {
                    JOptionPane.showMessageDialog(null, "Proszę zaznaczyć w tabeli pracownika do usunięcia ",
                            "InfoBox: ", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        });

        confirm.addActionListener(new ActionListener() {
            String adres = MainWindow.this.adresField.getText();
            @Override
            public void actionPerformed(ActionEvent actionEvent) {

                String imie = MainWindow.this.imieField.getText();
                String nazwisko = MainWindow.this.nazwiskoField.getText();
                Pracownik.genderDef plecField;

                if (MainWindow.this.plecField.getSelectedIndex() == 0)
                    plecField = Pracownik.genderDef.KOBIETA;
                else
                    plecField = Pracownik.genderDef.MEZCZYZNA;

                String adres = MainWindow.this.adresField.getText();
                String pesel = MainWindow.this.peselField.getText();
                String dataUrodzenia = MainWindow.this.dataUrodzeniaField.getText();
                String rachunek = MainWindow.this.rachunekField.getText();

                int godziny = tryToConvertToInt(MainWindow.this.godzinyLiczba.getText(), "godzinyLiczba");
                double pensja = tryToConvertToDouble(MainWindow.this.pensjaField.getText(), "pensja");
                double bonus = tryToConvertToDouble(MainWindow.this.bonusField.getText(), "bonus");

                int plecInd = MainWindow.this.plecField.getSelectedIndex();
                Pracownik.genderDef plec = defineGender(plecInd);


                //podstawowe sprawdzenie poprawnosci danych; czy nie sa puste pola
                if ((!imie.isEmpty() && !nazwisko.isEmpty() && !adres.isEmpty() && !pesel.isEmpty() && !adres.isEmpty()
                        && !dataUrodzenia.isEmpty() && !rachunek.isEmpty())
                        && DataValidator.validatePesel(pesel)
                        && DataValidator.validateBankAccount(rachunek)
                        && DataValidator.validateDateOfBirth(dataUrodzenia,pesel)
                        && DataValidator.validateGender(plec, pesel)
                )  {
                        //jezeli dane poprawne - tworzymy obiekt
                         int typInt = MainWindow.this.typPracownikaField.getSelectedIndex();
                         //0 - Administracyjny, 1 - Kierownik, 2 - Fizyczny

                         Pracownik pracownik = createPracownik(typInt, plecField, imie, nazwisko, pesel,
                                                        dataUrodzenia, adres, rachunek, pensja, bonus, godziny);

                         if (pracownik != null)
                            MainWindow.this.pracownikList.add(pracownik);
                            MainWindow.this.refreshData(MainWindow.this.tabelaPracownikow, MainWindow.this.pracownikList);
                            confirm.setEnabled(false);
                            clearFormularz();

                }
                else {
                    StringBuilder message = new StringBuilder("Proszę sprawdzic poprawność danych w formularzu. W polach : ");
                    if (imie.isEmpty()) message.append("imie, ");
                    if (nazwisko.isEmpty()) message.append("nazwisko, ");
                    if (pesel.isEmpty() || !DataValidator.validatePesel(pesel)) message.append("pesel, ");
                    if (adres.isEmpty()) message.append("adres, ");
                    if (dataUrodzenia.isEmpty() || !DataValidator.validateDateOfBirth(dataUrodzenia,pesel))
                        message.append("data urodzenia, ");
                    if (rachunek.isEmpty()) message.append("rachunek ");
                    if (!DataValidator.validateGender(plec, pesel)) message.append("plec lub pesel, ");

                    if (message.toString().endsWith(", ")) {
                        String tmp = message.toString().substring(0, message.length() - 2);
                        tmp += ".";
                        message = new StringBuilder(tmp);
                    }
                    JOptionPane.showMessageDialog(null, message ,
                            "InfoBox: ", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        });
        dodajPracownikaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                confirm.setEnabled(true);
            }
        });
        edytujPensjeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {

                int selectedRow = MainWindow.this.tabelaPracownikow.getSelectedRow();
                if (selectedRow >= 0) {
                  //  confirm.setEnabled(false);
                    Pracownik prac = MainWindow.this.pracownikList.get(selectedRow);
                    setDataToEdit(prac);
                    MainWindow.this.pracownikList.remove(selectedRow);
                    confirm.setEnabled(true);

                } else {
                    JOptionPane.showMessageDialog(null, "Proszę wybrać pracownika z tabeli ",
                            "InfoBox: ", JOptionPane.INFORMATION_MESSAGE);

                }

                confirm.setEnabled(true);
            }
        });
        helpButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null,
                        "Wczytanie listy pracowników:\nKliknij na przycisk wczytaj listę, wybierz listę, kliknij ok i gotowe.\n\n" +
                                "Usuwanie pracownika:\nZaznacz wiersz w tabeli z pracownikiem, którego chcesz usunąć i kliknij na przycisk Usuń pracownika.\n\n" +
                                "Dodawania pracownika:\nKliknij na przycisk Dodaj pracownika, uzupełnij dane i Zatwierdz.\n\n" +
                                "Generowanie raportu płac: \nKliknij na przycisk Generuj raport płac i gotowe.\n\n" +
                                "Edytuj dane: \nZaznacz wiersz z pracownikiem, którego dane chcesz wyedytować, kliknij na przycisk Edytuj zmiany, nanieś poprawki i Zatwierdź.",
                        "Help ", JOptionPane.INFORMATION_MESSAGE);
            }
        });



        wygenerujRaportPlacButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{
                    File myFile = new File("pracownicy_raport.txt");
                    PrintWriter writer = new PrintWriter(myFile.getAbsolutePath(), "UTF-8");


                    StringBuilder sb = new StringBuilder();
                    for (Pracownik p : MainWindow.this.pracownikList) {
                        sb.append(String.valueOf(wyliczWynagrodzenie(p)) + " zł " +p.toString());
                    }
                    writer.print(sb);
                    writer.close();

                    JOptionPane.showMessageDialog(null, "Raport został poprawnie wygenerowany w lokalizacji: \"" + myFile.getAbsolutePath() + "\"",
                            "InfoBox: ", JOptionPane.INFORMATION_MESSAGE);
                } catch (IOException ex) {
                    JOptionPane.showMessageDialog(null, "Nie można utworzyć raportu.",
                            "InfoBox: ", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        typPracownikaField.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent event) {
                if (event.getStateChange() == ItemEvent.SELECTED) {
                    Object item = event.getItem();
                    if (item.toString().equals("PRACOWNIK FIZYCZNY")) {
                        //pracownik fizyczny
                        pensjaLabel.setText("Stawka godzinowa pracownika");
                        godzinyLiczba.setVisible(true);
                        fizycznyGodzinyLabel.setVisible(true);
                        bonusField.setVisible(false);
                        bonusLabel.setVisible(false);

                    } else if (item.toString().equals("PRACOWNIK ADMINISTRACYJNY")) {
                        //pracownik administracyjny
                        pensjaLabel.setText("Pensja miesieczna");
                        godzinyLiczba.setVisible(false);
                        fizycznyGodzinyLabel.setVisible(false);
                        bonusField.setVisible(false);
                        bonusLabel.setVisible(false);
                    } else {
                        //Kierownik
                        pensjaLabel.setText("Pensja miesieczna");
                        godzinyLiczba.setVisible(false);
                        fizycznyGodzinyLabel.setVisible(false);
                        bonusField.setVisible(true);
                        bonusLabel.setVisible(true);
                    }
                }
            }
        });
    }


    public double wyliczWynagrodzenie (Pracownik p){
        if (p instanceof PracownikAdministracyjny)
           return ((PracownikAdministracyjny) p).obliczPensje();
        else if (p instanceof Kierownik) {
            return ((Kierownik) p).obliczPensje();
        } else if (p instanceof PracownikFizyczny) {
            return ((PracownikFizyczny) p).obliczPensje();
        }
        return 0;
    }

    private int tryToConvertToInt(String fieldValue, String fieldName) {
        int result = -1; // oznacza niepoprawna konwersje danych
        try {
            result = Integer.parseInt(fieldValue);
        } catch (Exception ex) {
            //unable to parse
          System.out.println("Niepoprawna wartosc w polu " + fieldName);
        }

        return result;
    }

    private double tryToConvertToDouble(String fieldValue, String fieldName) {
        double result = -1; // oznacza niepoprawna konwersje danych
        try {
            result = Double.parseDouble(fieldValue);
        } catch (Exception ex) {
            //unable to parse
           System.out.println("Niepoprawna wartosc w polu " + fieldName);
        }

        return result;
    }

    private Pracownik.genderDef defineGender(int ind) {
        if (ind == 0)
            return Pracownik.genderDef.KOBIETA;
        else
            return Pracownik.genderDef.MEZCZYZNA;
    }
    private Pracownik createPracownik(
            int typInt, Pracownik.genderDef plecField, String imie, String nazwisko, String pesel,
            String dataUrodzenia, String adres, String rachunek, double pensja, double bonus, int godziny) {
        Pracownik pracownik;
        if (typInt == 0) {
            pracownik = new PracownikAdministracyjny(
                    plecField,
                    imie,
                    nazwisko,
                    pesel,
                    dataUrodzenia,
                    adres,
                    rachunek,
                    pensja

            );
        } else if (typInt == 1) {
            pracownik = new Kierownik(
                    plecField,
                    imie,
                    nazwisko,
                    pesel,
                    dataUrodzenia,
                    adres,
                    rachunek,
                    pensja,
                    bonus
            );
        } else {
            pracownik = new PracownikFizyczny(
                    plecField,
                    imie,
                    nazwisko,
                    pesel,
                    dataUrodzenia,
                    adres,
                    rachunek,
                    pensja,
                    godziny
            );
        }
        return pracownik;
    }

    private void setSampleData() {
        MainWindow.this.imieField.setText("Justyna");
        MainWindow.this.nazwiskoField.setText("Kowalczyk");
        MainWindow.this.adresField.setText("Makuszynskiego 12 61-444 Gdynia");
        MainWindow.this.peselField.setText("81102419505");
        MainWindow.this.dataUrodzeniaField.setText("24-10-1981");
        MainWindow.this.rachunekField.setText("PL43203033233211935456193247");
        MainWindow.this.pensjaField.setText("5670.90");
    }

    private void setDataToEdit(Pracownik prac) {

        MainWindow.this.imieField.setText(prac.getName());
        MainWindow.this.nazwiskoField.setText(prac.getSurname());
        MainWindow.this.adresField.setText(prac.getAddress());

        // Unable to edit pesel
        MainWindow.this.peselField.setText(prac.getPesel());
        MainWindow.this.peselField.setEnabled(false);

        MainWindow.this.dataUrodzeniaField.setText(prac.getDateOfBirth());
        MainWindow.this.dataUrodzeniaField.setEnabled(false);


        //0 - Administracyjny, 1 - Kierownik, 2 - Fizyczny

        int typInt = MainWindow.this.typPracownikaField.getSelectedIndex();

        if (typInt == 0)
            MainWindow.this.typPracownikaField.setActionCommand(PRAC_ADMINISTRACYJNY);

        else if (typInt == 1) {
            MainWindow.this.typPracownikaField.setActionCommand(PRAC_KIEROWNIK);
        }
        else if (typInt == 2) {
            MainWindow.this.typPracownikaField.setActionCommand(PRAC_FIZYCZNY);
        }

        MainWindow.this.plecField.setEnabled(false);
        MainWindow.this.rachunekField.setText(prac.getBankAccount());

        if (prac instanceof PracownikAdministracyjny)
            MainWindow.this.pensjaField.setText(String.valueOf(((PracownikAdministracyjny) prac).getMonthlySalary()));
        else if (prac instanceof Kierownik) {
            MainWindow.this.pensjaField.setText(String.valueOf(((Kierownik) prac).getMonthlySalary()));
            MainWindow.this.pensjaField.setText(String.valueOf(((Kierownik) prac).getBonus()));
        }
        else if (prac instanceof PracownikFizyczny) {
            MainWindow.this.pensjaField.setText(String.valueOf(((PracownikFizyczny) prac).getLiczbaGodz()));
            MainWindow.this.pensjaField.setText(String.valueOf(((PracownikFizyczny) prac).getStawkaGodz()));
        }

    }
    private void clearFormularz() {
        MainWindow.this.imieField.setText("");
        MainWindow.this.nazwiskoField.setText("");
        MainWindow.this.adresField.setText("");
        MainWindow.this.peselField.setText("");
        MainWindow.this.dataUrodzeniaField.setText("");
        MainWindow.this.rachunekField.setText("");
        MainWindow.this.pensjaField.setText("");
        MainWindow.this.peselField.setEnabled(true);
        MainWindow.this.dataUrodzeniaField.setEnabled(true);
        MainWindow.this.typPracownikaField.setEnabled(true);
        MainWindow.this.plecField.setEnabled(true);
    }
    //odswiezanie okna zawierajacego tabele z pracownikami
    private void refreshData(JTable tabelaPracownikow, List<Pracownik> pracownikList) {
        DefaultTableModel dm = this.getPracownikTableModel();
        int rowCount = dm.getRowCount();
        for (int i = rowCount - 1; i >= 0; i--) {
            dm.removeRow(i);
        }

        for(Pracownik p: pracownikList){
            if (p instanceof PracownikAdministracyjny)
                dm.addRow(new Object[]{p.getName(), p.getSurname(), p.getGender().toString(),  p.getPesel(), p.getDateOfBirth(), p.getAddress(),
                        p.getBankAccount(), PRAC_ADMINISTRACYJNY, String.valueOf(((PracownikAdministracyjny) p).obliczPensje())});
            else if (p instanceof Kierownik)
                dm.addRow(new Object[]{p.getName(), p.getSurname(), p.getGender().toString(),  p.getPesel(), p.getDateOfBirth(), p.getAddress(),
                         p.getBankAccount(), PRAC_KIEROWNIK, String.valueOf(((Kierownik) p).obliczPensje())});
            else if (p instanceof PracownikFizyczny)
                dm.addRow(new Object[]{p.getName(), p.getSurname(), p.getGender().toString(),  p.getPesel(), p.getDateOfBirth(), p.getAddress(),
                        p.getBankAccount(), PRAC_FIZYCZNY, String.valueOf(((PracownikFizyczny) p).obliczPensje())});
        }

    }

    private DefaultTableModel getPracownikTableModel() {
        if(pracownikTableModel == null){
            pracownikTableModel = new DefaultTableModel();
            pracownikTableModel.addColumn("Imię");
            pracownikTableModel.addColumn("Nazwisko");
            pracownikTableModel.addColumn("Płeć");
            pracownikTableModel.addColumn("Pesel");
            pracownikTableModel.addColumn("Data ur.");
            pracownikTableModel.addColumn("Adres");
            pracownikTableModel.addColumn("Nr rach. bankowego");
            pracownikTableModel.addColumn("Typ pracownika");
            pracownikTableModel.addColumn("Wysok.wynagrodzenia");
        }
        return pracownikTableModel;
    }
    public JPanel getSuperHRView() {
        return superHRView;
    }

    private JPanel superHRView;
    private JButton usunPracownikaButton;
    private JButton wygenerujRaportPlacButton;
    private JButton dodajPracownikaButton;
    private JButton edytujPensjeButton;
    private JTable tabelaPracownikow;
    private JButton wczytajListe;
    private JPanel DetailView;
    private JButton Confirm;
    private JPanel dodajPracownikaPanel;
    private JFormattedTextField imieField;
    private JPanel Nazwisko;
    private JFormattedTextField nazwiskoField;
    private JPanel plec;
    private JComboBox plecField;
    private JPanel pesel;
    private JFormattedTextField peselField;
    private JPanel dataUrodzenia;
    private JFormattedTextField dataUrodzeniaField;
    private JPanel adres;
    private JFormattedTextField adresField;
    private JPanel rachunek;
    private JFormattedTextField rachunekField;
    private JPanel rodzaj;
    private JButton confirm;
    private JPanel panelConfirm;
    private JPanel imie;
    private JTextField pensjaField;
    private JButton helpButton;
    private JComboBox typPracownikaField;
    private JTextField godzinyLiczba;
    private JLabel fizycznyGodzinyLabel;
    private JLabel pensjaLabel;
    private JTextField bonusField;
    private JLabel bonusLabel;
    private JButton confirmationAddEdit;
    private DefaultTableModel pracownikTableModel;
    private final JFileChooser fc = new JFileChooser();

    public List<Pracownik> getPracownikList() {
        return pracownikList;
    }

    public void setPracownikList(List<Pracownik> pracownikList) {
        this.pracownikList = pracownikList;
    }

    private List<Pracownik> pracownikList = new ArrayList<Pracownik>();

}
