package pl.edu.pjwstk.util;

import pl.edu.pjwstk.model.Pracownik;
import pl.edu.pjwstk.model.PracownikFactory;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class Datasource {
    public static List<Pracownik> deserialize(String path) throws IOException {
        List<String> lines = Files.readAllLines(Paths.get(path), Charset.defaultCharset());
        List<Pracownik> result = new ArrayList<Pracownik>();
        for(String line: lines){
            String[] components = line.split(",");
            Pracownik tmp = PracownikFactory.stworzPracownika(components);
            if (tmp != null)
                result.add(tmp);
        }
        return result;
    }
}
