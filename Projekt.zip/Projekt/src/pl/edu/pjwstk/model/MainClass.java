package pl.edu.pjwstk.model;


import pl.edu.pjwstk.gui.MainWindow;

import javax.swing.*;

public class MainClass {

    public static void main(String[] args) {
        try {
            JFrame frame = new JFrame("HR Pracownicy");
    //        frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
    //        frame.setUndecorated(true);
            frame.setSize(600, 400);
            frame.setLocationRelativeTo(null);
            frame.setContentPane(new MainWindow().getSuperHRView());
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.pack();
            frame.setVisible(true);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Błąd aplikacji ",
                    "InfoBox: ", JOptionPane.INFORMATION_MESSAGE);
        }
    }
}
