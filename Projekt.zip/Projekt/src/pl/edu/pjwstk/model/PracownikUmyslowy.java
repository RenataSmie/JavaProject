package pl.edu.pjwstk.model;

public class PracownikUmyslowy extends Pracownik{


    private double monthlySalary;

    public double getMonthlySalary() {
        return monthlySalary;
    }

    public void setMonthlySalary(double monthlySalary) {
        this.monthlySalary = monthlySalary;
    }

    public PracownikUmyslowy(genderDef gender, String name, String surname, String pesel, String dateOfBirth, String address, String bankAccount, double monthlySalary) {
        super(gender, name, surname, pesel, dateOfBirth, address, bankAccount);
        this.monthlySalary = monthlySalary;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(" " + this.getName() + " " + this.getSurname() + " ");
        sb.append(" " + this.getPesel() + " " + this.getDateOfBirth() + " ");
        sb.append(" " + this.getAddress() + " " + this.getBankAccount());
        return "Pracownik Umyslowy: " + sb.toString() + "\n" ;
    }


}
