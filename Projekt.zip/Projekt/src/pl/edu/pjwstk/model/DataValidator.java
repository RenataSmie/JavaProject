package pl.edu.pjwstk.model;

import java.math.BigInteger;

public class DataValidator {

    private static boolean validateName(String name) {
        if ((name.length() >= 2) && (name.matches("[A-Za-z]+"))) {
            return true;
        } else
            return false;
    }

    private static boolean validateSurname(String surname) {
        if ((surname.length() >= 2) && (surname.matches("[A-Za-z]+"))) {
            return true;
        } else
            return false;
    }

    public static boolean validatePesel(String pesel) {
        if ((9 * charAt(0) + 7 * charAt(1) + 3 * charAt(2) + 1 * charAt(3) + 9 * charAt(4) + 7 * charAt(5)
                + 3 * charAt(6) + 1 * charAt(7) + 9 * charAt(8) + 7 * charAt(9)) % 10 == charAt(10)) {
            return true;
        } else {
            return false;
        }
    }

    private static int charAt(int i) {
        return 0;
    }


    //np: PL29102034533163345226526556
    public static boolean validateBankAccount(String bankAccount) {

        if (bankAccount.length() != 28) {
            return false;
        }
        String w = bankAccount.substring(4) + DataValidator.countryCode(bankAccount.charAt(0))
                + DataValidator.countryCode(bankAccount.charAt(1)) + bankAccount.substring(2, 4);
        System.out.println(w);
        BigInteger reallyBig = new BigInteger(w);
        return reallyBig.mod(new BigInteger("97")).intValue() == 1;
    }

    private static String countryCode(char charAt) {
        return Integer.toString(charAt - 55);
    }

    public static boolean validateDateOfBirth(String dateOfBirth, String pesel) {

        if (dateOfBirth.length() != 10 | pesel.length() != 11)
            return false;

        String yearOfBirthFromPesel = DataValidator.yearCode(pesel.charAt(2)) + pesel.substring(0, 2);
        String monthOfBirthFromPesel = pesel.substring(2, 4);
        String dayOfBirthFromPesel = pesel.substring(4, 6);

        if (yearOfBirthFromPesel.equals(dateOfBirth.substring(6, 10))
                && monthOfBirthFromPesel.equals(dateOfBirth.substring(3, 5))
                && dayOfBirthFromPesel.equals(dateOfBirth.substring(0, 2))) {
            return true;
        } else {
            return false;
        }
    }

    private static String yearCode(char charAt) {
        if ((charAt == '0') || (charAt == '1')) {
            return Integer.toString(19);
        } else {
            return Integer.toString(20);
        }
    }


    public static boolean validateGender(Pracownik.genderDef gender, String pesel) {
        if (pesel.length() != 11)
            return false;
        if (((pesel.charAt(9) - '0') % 2 == 0) && (gender == Pracownik.genderDef.KOBIETA)) {
            return true;
        }
        if (((pesel.charAt(9) - '0') % 2 != 0) && (gender == Pracownik.genderDef.MEZCZYZNA)) {
            return true;
        } else {
            return false;
        }
    }

}
