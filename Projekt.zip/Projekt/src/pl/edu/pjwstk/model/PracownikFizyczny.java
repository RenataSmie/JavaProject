package pl.edu.pjwstk.model;

import pl.edu.pjwstk.podwyzki.IPracownik;

public class PracownikFizyczny extends Pracownik implements IPracownik {

    private double stawkaGodz;
    private int liczbaGodz;

    public void setStawkaGodz(double stawkaGodz) {
        this.stawkaGodz = stawkaGodz;
    }

    public void setLiczbaGodz(int liczbaGodz) {
        this.liczbaGodz = liczbaGodz;
    }

    public double getStawkaGodz() {
        return stawkaGodz;
    }

    public int getLiczbaGodz() {
        return liczbaGodz;
    }

    public PracownikFizyczny(genderDef gender, String name, String surname, String pesel, String dateOfBirth, String address, String bankAccount, double stawkaGodz, int liczbaGodz) {
        super(gender, name, surname, pesel, dateOfBirth, address, bankAccount);
        this.stawkaGodz = stawkaGodz;
        this.liczbaGodz = liczbaGodz;
    }
    @Override
    public String toString() {

        StringBuilder sb = new StringBuilder();
        sb.append(" " + this.getName() + " " + this.getSurname() + " ");
        sb.append(" " + this.getPesel() + " " + this.getDateOfBirth() + " ");
        sb.append(" " + this.getAddress() + " " + this.getBankAccount());
        return "Pracownik Fizyczny: " + sb.toString() + "\n" ;
    }

    public double obliczPensje(){
        return stawkaGodz * liczbaGodz;
    };
}
