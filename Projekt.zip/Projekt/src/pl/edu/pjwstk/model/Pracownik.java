package pl.edu.pjwstk.model;

import pl.edu.pjwstk.podwyzki.IPracownik;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public abstract class Pracownik {


    public genderDef getGender() {
        return gender;
    }

    public void setGender(genderDef gender) {
        this.gender = gender;
    }

    public enum genderDef {
        KOBIETA, MEZCZYZNA
    };

    private genderDef gender;

    private String name;
    private String surname;
    private String pesel;
    private String dateOfBirth; // zakladam dane w formacie DD-MM-YYYY
    private String address;
    private String bankAccount;

    // konstruktor
    public Pracownik(genderDef gender, String name, String surname, String pesel, String dateOfBirth, String address,
                     String bankAccount) {
        this.gender = gender;
        this.name = name;
        this.surname = surname;
        this.address = address;
        this.pesel = pesel;
        this.dateOfBirth = dateOfBirth;
        this.bankAccount = bankAccount;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getPesel() {
        return pesel;
    }

    public void setPesel(String pesel) {
        this.pesel = pesel;
    }

    public String getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getBankAccount() {
        return bankAccount;
    }

    public void setBankAccount(String bankAccount) {
        this.bankAccount = bankAccount;
    }


}

