package pl.edu.pjwstk.model;

import pl.edu.pjwstk.podwyzki.IPracownik;

public class Kierownik extends PracownikUmyslowy implements IPracownik{

    private double bonus;
    public double getBonus() {
        return bonus;
    }

    public void setBonus(double bonus) {
        this.bonus = bonus;
    }

    public Kierownik(genderDef gender, String name, String surname, String pesel, String dateOfBirth, String address, String bankAccount, double monthlySalary, double bonus) {
        super(gender, name, surname, pesel, dateOfBirth, address, bankAccount, monthlySalary);
        this.bonus = bonus;
    }

    public double obliczPensje(){ return getMonthlySalary() + bonus; };

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(" " + this.getName() + " " + this.getSurname() + " ");
        sb.append(" " + this.getPesel() + " " + this.getDateOfBirth() + " ");
        sb.append(" " + this.getAddress() + " " + this.getBankAccount());
        return "Kierownik: " + sb.toString() + "\n" ;
    }
}
