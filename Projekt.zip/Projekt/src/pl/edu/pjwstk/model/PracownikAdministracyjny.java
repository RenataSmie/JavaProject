package pl.edu.pjwstk.model;


import pl.edu.pjwstk.podwyzki.IPracownik;

public class PracownikAdministracyjny extends PracownikUmyslowy implements IPracownik {

    public static double DODATEK = 0.05;

    public PracownikAdministracyjny(genderDef gender, String name, String surname, String pesel, String dateOfBirth, String address, String bankAccount, double monthlySalary) {
        super(gender, name, surname, pesel, dateOfBirth, address, bankAccount, monthlySalary);
    }

    public double obliczPensje () { return getMonthlySalary() * (1+DODATEK); }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(" " + this.getName() + " " + this.getSurname() + " ");
        sb.append(" " + this.getPesel() + " " + this.getDateOfBirth() + " ");
        sb.append(" " + this.getAddress() + " " + this.getBankAccount());
        return "Pracownik Administracyjny: " + sb.toString() + "\n" ;
    }
}
