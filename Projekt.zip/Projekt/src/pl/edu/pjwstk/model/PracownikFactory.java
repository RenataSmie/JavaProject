package pl.edu.pjwstk.model;

public class PracownikFactory {
    public static Pracownik.genderDef ustalPlec(String val) {
        if (val.equals("k"))
            return Pracownik.genderDef.KOBIETA;
        else
            return Pracownik.genderDef.MEZCZYZNA;
    }
    public static Pracownik stworzPracownika(
        String[] components
    ){
        switch(components[0].charAt(0)){ //component 0 => pierwsza litera z pliku
            case 'a':{
                //type, gender, name, surname, pesel, dateOfBirth, address, bankAccount, double pensja, double bonus, int godziny
                PracownikAdministracyjny tmp;
                try {
                    tmp = new PracownikAdministracyjny(
                            ustalPlec(components[1]),
                            components[2],
                            components[3], components[4],
                            components[5], components[6],
                            components[7], Double.parseDouble(components[8])
                    );
                    return tmp;
                } catch (Exception ex){
                    System.out.println("Nie mozna stworzyc pracownika administracyjnego. Blad parsowania. " + ex.getMessage());
                }
            }
            case 'f':{
                PracownikFizyczny tmp;
                try {
                    tmp = new PracownikFizyczny(
                            ustalPlec(components[1]),
                            components[2],
                            components[3], components[4],
                            components[5], components[6],
                            components[7], Double.parseDouble(components[8]),
                            Integer.parseInt(components[9])
                    );
                    return tmp;
                } catch (Exception ex) {
                    System.out.println("Nie mozna stworzyc pracownika fizycznego. Blad parsowania. " + ex.getMessage());
                }
            }
            case 'k': {
                Kierownik tmp;
                try {
                    tmp = new Kierownik(
                            ustalPlec(components[1]),
                            components[2],
                            components[3], components[4],
                            components[5], components[6],
                            components[7], Double.parseDouble(components[8]), Double.parseDouble(components[9])
                    );
                    return tmp;
                } catch (Exception ex) {
                    System.out.println("Nie mozna stworzyc kierownik. Blad parsowania. " + ex.getMessage());
                }
            }

        }
        return null;
    }
}
